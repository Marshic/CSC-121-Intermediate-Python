# Donte' Brown & Jin Pak
# 1/29/25
# M4Pro

import m4_pro_functions as fn
courses = {
    "MAT-035": {"desc": "Concepts of Algebra", "tuition": 460},
    "CTI-115": {"desc": "Computer System Foundations", "tuition": 520.98},
    "BAS-120": {"desc": "Intro to Analytics", "tuition": 500},
    "CSC-121": {"desc": "Python Programming", "tuition": 783.88}
}

students = {
    "Zakari Watson": ["CTI-115", "CSC-121"],
    "Jerom Williams": ["CTI-115", "CSC-121", "MAT-035", "BAS-120"],
    "Dominique Ross": ["CTI-115", "CSC-121", "MAT-035"],
    "Diana Shepard": ["MAT-035", "CTI-115", "BAS-120", "CSC-121"],
    "Yoko Mayo": ["MAT-035"],
    "Rashad Ahmed": ["MAT-035", "BAS-120"],
    "Susan Jones": ["BAS-120", "CSC-121"]
}

def main():
    choice = 0
    while choice != 6: # exit program when 6 is chosen
        
        # call menu function
        fn.menu()
        
        #enter choice
        choice = int(input("Enter Choice: "))
        
        #evaluate what user entered
        
        if choice == 1: # Show all courses

            fn.dis_Course() # Display all courses, done
    
        
        elif choice == 2: # for a specific student

            fn.lookup_course()

        
        elif choice == 3:
            fn.display_one_student()

        elif choice == 4:
            fn.display_all() # done

        elif choice == 5:
            fn.cal_for_course() # done
        
        elif choice == 6: # done
            print("Program Terminating....")

        else:
            
            print("Invalid Entry!!!!")


if __name__ == "__main__":
    main()   
            

