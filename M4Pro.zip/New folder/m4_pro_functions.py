# Donte' Brown & Jin Pak
# 1/29/25
# M4Pro
courses = {
    "MAT-035": {"desc": "Concepts of Algebra", "tuition": 460},
    "CTI-115": {"desc": "Computer System Foundations", "tuition": 520.98},
    "BAS-120": {"desc": "Intro to Analytics", "tuition": 500},
    "CSC-121": {"desc": "Python Programming", "tuition": 783.88}
}

students = {
    "Zakari Watson": ["CTI-115", "CSC-121"],
    "Jerom Williams": ["CTI-115", "CSC-121", "MAT-035", "BAS-120"],
    "Dominique Ross": ["CTI-115", "CSC-121", "MAT-035"],
    "Diana Shepard": ["MAT-035", "CTI-115", "BAS-120", "CSC-121"],
    "Yoko Mayo": ["MAT-035"],
    "Rashad Ahmed": ["MAT-035", "BAS-120"],
    "Susan Jones": ["BAS-120", "CSC-121"]
}

def menu(): # Menu!
    print("-----------------------MENU---------------------------")
    print("1) Display Course Information")
    print("2) Lookup Course")
    print("3) Display Courses and Tuition for Specific Student")
    print("4) Display Tuition for ALL Students")
    print("5) Display # of Students and Tuition for ALL Courses")
    print("6) Exit")
    print("-" * 54)
    print()

def dis_Course(): # 1
    print(f'{"Code":<10}{"Description":<35}{"Tuition"}')
    print("-"*60)
    for code, info in courses.items():
        print(f'{code:<10}{info["desc"]:<35}{info["tuition"]}')
    print()

def lookup_course(): # 2
    run_again = "yes"
    while run_again == "yes":
        code = input("Enter the course code you wish to look up: ")
        for cod in courses:
            if code == cod:
                for descrip, info in courses[cod].items():
                    print(f"{descrip}: {info}")
            else:
                print("Course not found, re-enter...")
    run_again = input("Run Again? ")
print("Back to Menu.")


def display_one_student(): # 3
    stu_names = ["Zakari Watson", "Jerom Williams", "Dominique Ross", "Diana Shepard", "Yoko Mayo", "Rashad Ahmed", "Susan Jones"]
    for s in range(len(stu_names)):
        print(f"{s+1}) {stu_names[s]}")
    stu = int(input("Choose a student: "))

    print(f'You chose {stu_names[stu-1]}')

def display_all(): # 4
    
    print(f'{"Stu Name":<30}{"# of Courses":<15}{"Tuition"}')
    print("-" * 50)
    overall_tuit = 0
    for name, num in students.items(): # for each student loop
        total_tuit = 0

        for c in num: # for each course in that course list for each student
            for course in courses: # for each course in the courses dictionary
                if c == course: # if the courses match up in the student's list and in the courses dictionary
                    stu_tuit = (courses[course]["tuition"]) # the tuition for that student for a specific class
                    total_tuit += stu_tuit # all tuitiuon up for that student
        print(f'{name:<30}{len(num):<15}${total_tuit:.2f}') # display
        overall_tuit += total_tuit
    print("-" * 50)
    print(f"{'Overall Total:':<45}${overall_tuit:.2f}")

    '''
    for s in students: # example
        tot_tuition = 0
        num_classes = 0
        print(f"{s} is taking classes {students[s]}") # students[s] is the list of classes for that student
        # Loop through each student classes
        for c in students[s]: # c is the individual class their taking
            #print(c)
            for course in courses:
                #print(course) # each course in the dictionary
                if c == course:
                    num_classes += 1
                    stu_tuit = (courses[course]["tuition"])
                    tot_tuition += stu_tuit
        print(f"{s} {num_classes} ${tot_tuition}")
    '''
    print("-" * 50)
    print()


def cal_for_course(): # 5
    print(f'{"Course Code":<15}{"# of Stu":<10}{"Tuition Generated"}')
    print("-" * 50)

    for code, info in courses.items():
        num_stud = 0
        total_tuit = 0
        for s, study in students.items():
            for c in study:
                #print(study)
                if code == c:
                    num_stud += 1
                    total_tuit += info["tuition"]
                    overall_tuit += total_tuit
        print(f"{code:<15}{num_stud:<10}${total_tuit:.2f}")

