from M5LAB_functions_Donte import readFile, calc_tot_products, write_tot_products
def main():
    data = readFile()
    products = calc_tot_products(data)
    write_tot_products(products)

# Call main function
if __name__ == "__main__":
    main()