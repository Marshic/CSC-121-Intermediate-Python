import csv
def readFile():
    with open("sales.csv", "r") as file:
        # Create a csv object
        reader = csv.reader(file)
    return reader

def calc_tot_products(reader):
    products = {}

    with open("sales.csv", "r") as file:
        # Create a csv object
        reader = csv.reader(file)
        next(reader)
        for row in reader:
            print(row)
            if row[2] not in products:
                products[row[2]] = int(row[4]) * float(row[5])
            else: 
                products[row[2]] += int(row[4]) * float(row[5])
        for key, value in products.items():
            print(f'Product ID: {key}  ${value:.2f}')
    return products

def write_tot_products(products):
    with open("Total_sales.csv", "w") as file:
        columnnames = ["Product ID", "Total Sales"]
        writer = csv.DictWriter(file, fieldnames=columnnames)
        results = [{"Product ID": key, "Total Sales": value} for key, value in products.items()]
        writer.writeheader()  # Write column names
        writer.writerows(results)

