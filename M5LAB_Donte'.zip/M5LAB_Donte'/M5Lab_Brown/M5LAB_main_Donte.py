from m5LAB_functions_JinPak import readFile, calc_tot_products, write_tot_products

#Jin Pak
# m5_LAB

def main():
    data = readFile()
    products = calc_tot_products(data)
    write_tot_products(products)



# Call main function
if __name__ == "__main__":
    main()